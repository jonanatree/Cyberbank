package p

var S1 string
var S2 string
var S3 string
var S4 string
var S5 string
var S6 string
var S7 string
var S8 string
var S9 string
var S10 string
