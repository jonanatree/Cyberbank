# load balancer

Simple load balancing library for Golang. Spreads workload among predefined number of goroutines.
