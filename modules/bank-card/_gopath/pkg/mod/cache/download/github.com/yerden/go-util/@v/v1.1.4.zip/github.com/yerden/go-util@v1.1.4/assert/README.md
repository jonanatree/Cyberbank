# assert

Simple assert package used for testing.
