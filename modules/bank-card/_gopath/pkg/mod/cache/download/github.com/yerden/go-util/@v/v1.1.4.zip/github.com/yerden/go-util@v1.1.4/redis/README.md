Overview
========

This package wraps Redis db access and local concurrent map as a cache.

Dependencies:
* [Redis driver](https://github.com/mediocregopher/radix.v2).
