// Version will be automatically set during the build
package iso8583

var Version string
