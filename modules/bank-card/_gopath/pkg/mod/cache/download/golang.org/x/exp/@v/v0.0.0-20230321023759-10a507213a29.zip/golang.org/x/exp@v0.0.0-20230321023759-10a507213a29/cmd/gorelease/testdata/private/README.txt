Module example.com/private is used to test that changes to
internal packages are not reported unless they affect the exported
API of non-internal packages.
